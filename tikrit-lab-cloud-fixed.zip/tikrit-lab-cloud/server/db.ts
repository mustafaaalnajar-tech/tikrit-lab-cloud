import { and, eq } from "drizzle-orm";
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, LabRecord, InsertLabRecord, labRecords, users, User } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
const LOCAL_SESSION_COOKIE = "tikrit_lab_session";

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export function localSessionCookieName() { return LOCAL_SESSION_COOKIE; }
function hashToken(token: string) { return createHash("sha256").update(token).digest("hex"); }
export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}
export function verifyPassword(password: string, stored: string | null | undefined) {
  if (!stored) return false;
  const [salt, digest] = stored.split(":");
  if (!salt || !digest) return false;
  const actual = scryptSync(password, salt, 64);
  const expected = Buffer.from(digest, "hex");
  return expected.length === actual.length && timingSafeEqual(actual, expected);
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  values.lastSignedIn = user.lastSignedIn || new Date(); updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}
export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; return (await db.select().from(users).where(eq(users.openId, openId)).limit(1))[0]; }
export async function getUserByUsername(username: string) { const db = await getDb(); if (!db) return undefined; return (await db.select().from(users).where(eq(users.username, username)).limit(1))[0]; }
export async function ensureLocalAdmin() {
  const existing = await getUserByUsername("admin");
  if (existing) return existing;
  const db = await getDb();
  if (!db) return undefined;
  const passwordHash = hashPassword("1234");
  await db.insert(users).values({ openId: "local:admin", username: "admin", passwordHash, name: "مدير المختبر", role: "admin", loginMethod: "local" });
  return getUserByUsername("admin");
}
export async function createLocalSession(userId: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const token = randomBytes(32).toString("base64url");
  await db.update(users).set({ sessionTokenHash: hashToken(token), lastSignedIn: new Date() }).where(eq(users.id, userId));
  return token;
}
export async function getUserBySessionToken(token: string | undefined) {
  const db = await getDb(); if (!db || !token) return undefined;
  return (await db.select().from(users).where(eq(users.sessionTokenHash, hashToken(token))).limit(1))[0];
}
export async function changeLocalPassword(userId: number, password: string) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.id, userId));
}

export async function getLabRecords(ownerId: number): Promise<LabRecord[]> { const db = await getDb(); if (!db) return []; return db.select().from(labRecords).where(eq(labRecords.ownerId, ownerId)); }
export type SyncRecordInput = { id: string; type: "patient" | "report"; payload: Record<string, unknown>; updatedAt: number; deletedAt?: number | null };
export async function mergeLabRecords(ownerId: number, incoming: SyncRecordInput[]) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const current = await getLabRecords(ownerId); const byId = new Map(current.map(record => [record.recordId, record]));
  for (const item of incoming) {
    const existing = byId.get(item.id); if (existing && Number(existing.updatedAt) > item.updatedAt) continue;
    const values: InsertLabRecord = { ownerId, recordId: item.id, recordType: item.type, data: item.payload, updatedAt: item.updatedAt, deletedAt: item.deletedAt ?? null };
    if (existing) await db.update(labRecords).set({ recordType: values.recordType, data: values.data, updatedAt: values.updatedAt, deletedAt: values.deletedAt }).where(and(eq(labRecords.ownerId, ownerId), eq(labRecords.recordId, item.id)));
    else await db.insert(labRecords).values(values);
    byId.set(item.id, { ...existing, ...values, id: existing?.id ?? 0, createdAt: existing?.createdAt ?? new Date() } as LabRecord);
  }
  return getLabRecords(ownerId);
}
