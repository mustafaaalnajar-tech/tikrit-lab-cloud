import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { changeLocalPassword, ensureLocalAdmin, getLabRecords, getUserBySessionToken, getUserByUsername, localSessionCookieName, mergeLabRecords, verifyPassword, createLocalSession } from "./db";
import { TRPCError } from "@trpc/server";

const syncRecord = z.object({ id: z.string().min(1).max(96), type: z.enum(["patient", "report"]), payload: z.record(z.string(), z.unknown()), updatedAt: z.number().int().positive(), deletedAt: z.number().int().positive().nullable().optional() });
const accountShape = z.object({ username: z.string().trim().min(3).max(64).regex(/^[a-zA-Z0-9_.-]+$/), password: z.string().min(4).max(128) });

function toClientRecord(record: Awaited<ReturnType<typeof getLabRecords>>[number]) { return { id: record.recordId, type: record.recordType, payload: record.data as Record<string, unknown>, updatedAt: Number(record.updatedAt), deletedAt: record.deletedAt == null ? null : Number(record.deletedAt) }; }
function localTokenFromRequest(req: { headers: { cookie?: string } }) { return req.headers.cookie?.split(";").map(value => value.trim()).find(value => value.startsWith(`${localSessionCookieName()}=`))?.slice(localSessionCookieName().length + 1); }

const localProcedure = publicProcedure.use(async ({ ctx, next }) => {
  const user = await getUserBySessionToken(localTokenFromRequest(ctx.req));
  if (!user) throw new TRPCError({ code: "UNAUTHORIZED", message: "اسم المستخدم أو الرمز غير صحيح" });
  return next({ ctx: { ...ctx, user } });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  account: router({
    login: publicProcedure.input(accountShape).mutation(async ({ ctx, input }) => {
      const existing = await getUserByUsername(input.username);
      const user = existing || (input.username === "admin" ? await ensureLocalAdmin() : undefined);
      if (!user || !verifyPassword(input.password, user.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "اسم المستخدم أو الرمز غير صحيح" });
      const token = await createLocalSession(user.id);
      ctx.res.cookie(localSessionCookieName(), token, { httpOnly: true, secure: true, sameSite: "none", maxAge: 60 * 60 * 24 * 30, path: "/" });
      return { username: user.username, name: user.name, role: user.role };
    }),
    me: localProcedure.query(({ ctx }) => ({ username: ctx.user.username, name: ctx.user.name, role: ctx.user.role })),
    changePassword: localProcedure.input(z.object({ currentPassword: z.string().min(4), newPassword: z.string().min(4).max(128) })).mutation(async ({ ctx, input }) => {
      if (!verifyPassword(input.currentPassword, ctx.user.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "الرمز الحالي غير صحيح" });
      await changeLocalPassword(ctx.user.id, input.newPassword);
      return { success: true } as const;
    }),
    logout: publicProcedure.mutation(({ ctx }) => { ctx.res.clearCookie(localSessionCookieName(), { httpOnly: true, secure: true, sameSite: "none", maxAge: -1, path: "/" }); return { success: true } as const; }),
  }),
  lab: router({
    snapshot: localProcedure.query(async ({ ctx }) => ({ serverTime: Date.now(), records: (await getLabRecords(ctx.user.id)).map(toClientRecord) })),
    sync: localProcedure.input(z.object({ records: z.array(syncRecord).max(5000) })).mutation(async ({ ctx, input }) => ({ serverTime: Date.now(), records: (await mergeLabRecords(ctx.user.id, input.records)).map(toClientRecord) })),
  }),
});

export type AppRouter = typeof appRouter;
