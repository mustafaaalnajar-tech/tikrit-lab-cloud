import { bigint, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  username: varchar("username", { length: 64 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  sessionTokenHash: varchar("sessionTokenHash", { length: 64 }),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const labRecords = mysqlTable(
  "labRecords",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull(),
    recordId: varchar("recordId", { length: 96 }).notNull(),
    recordType: mysqlEnum("recordType", ["patient", "report"]).notNull(),
    data: json("data").notNull(),
    updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
    deletedAt: bigint("deletedAt", { mode: "number" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ ownerRecordUnique: uniqueIndex("labRecords_owner_record_unique").on(table.ownerId, table.recordId) }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type LabRecord = typeof labRecords.$inferSelect;
export type InsertLabRecord = typeof labRecords.$inferInsert;
