CREATE TABLE `labRecords` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`recordId` varchar(96) NOT NULL,
	`recordType` enum('patient','report') NOT NULL,
	`data` json NOT NULL,
	`updatedAt` bigint NOT NULL,
	`deletedAt` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `labRecords_id` PRIMARY KEY(`id`),
	CONSTRAINT `labRecords_owner_record_unique` UNIQUE(`ownerId`,`recordId`)
);
