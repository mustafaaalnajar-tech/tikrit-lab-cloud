import { trpc } from "@/lib/trpc";
import { useCallback, useEffect, useRef, useState } from "react";
import { Cloud, CloudOff, Loader2, LogIn, LogOut, RefreshCw, ShieldCheck } from "lucide-react";
import type { LabRecord } from "@/lib/offlineSync";

const PATIENTS_KEY = "saladin_lab_patients_v1";
const REPORTS_KEY = "saladin_lab_reports_v1";
const META_KEY = "tikrit_lab_sync_meta_v1";
const IDENTITY_KEY = "tikrit_lab_last_identity_v1";
const LOCAL_USERNAME_KEY = "tikrit_lab_local_username_v1";

type Status = "loading" | "syncing" | "synced" | "local";

type SyncMeta = Record<string, { updatedAt: number; hash: string; type: "patient" | "report" }>;

function readArray(key: string): Record<string, unknown>[] {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}
function writeArray(key: string, value: Record<string, unknown>[]) { localStorage.setItem(key, JSON.stringify(value)); }
function readMeta(): SyncMeta { try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch { return {}; } }
function writeMeta(value: SyncMeta) { localStorage.setItem(META_KEY, JSON.stringify(value)); }
function recordId(type: "patient" | "report", value: Record<string, unknown>) { return `${type}:${String(value.id)}`; }
function stableHash(value: Record<string, unknown>) { return JSON.stringify(value); }

function collectLocalRecords(): { records: LabRecord[]; meta: SyncMeta } {
  const meta = readMeta();
  const source: LabRecord[] = [];
  for (const [type, key] of [["patient", PATIENTS_KEY], ["report", REPORTS_KEY]] as const) {
    for (const item of readArray(key)) {
      if (item.id == null) continue;
      const id = recordId(type, item);
      const hash = stableHash(item);
      const previous = meta[id];
      const updatedAt = previous && previous.hash === hash ? previous.updatedAt : Date.now();
      meta[id] = { updatedAt, hash, type };
      source.push({ id, type, payload: item, updatedAt, deletedAt: null });
    }
  }
  return { records: source, meta };
}

function applyServerRecords(records: LabRecord[]) {
  const patients: Record<string, unknown>[] = [];
  const reports: Record<string, unknown>[] = [];
  const meta = readMeta();
  for (const item of records) {
    const id = item.id.split(":").slice(1).join(":");
    if (item.deletedAt) {
      delete meta[item.id];
      continue;
    }
    const payload = { ...item.payload, id: item.payload.id ?? (Number(id) || id) };
    const hash = stableHash(payload);
    meta[item.id] = { updatedAt: item.updatedAt, hash, type: item.type };
    if (item.type === "patient") patients.push(payload); else reports.push(payload);
  }
  writeArray(PATIENTS_KEY, patients);
  writeArray(REPORTS_KEY, reports);
  writeMeta(meta);
}

export default function Home() {
  // The laboratory uses its own local username/password account. Do not invoke
  // the platform OAuth flow here: it asks for an email and blocks offline use.
  const isAuthenticated = false;
  const user = null;
  const logout = async () => {};
  const [online, setOnline] = useState(() => typeof navigator === "undefined" ? true : navigator.onLine);
  const cachedIdentity = typeof window === "undefined" ? "" : localStorage.getItem(IDENTITY_KEY) || "";
  const [localUser, setLocalUser] = useState(() => typeof window === "undefined" ? "" : localStorage.getItem(LOCAL_USERNAME_KEY) || "");
  const [accountOpen, setAccountOpen] = useState(false);
  const [accountMode, setAccountMode] = useState<"login" | "change">("login");
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [accountNotice, setAccountNotice] = useState("");
  const localLogin = trpc.account.login.useMutation({ onSuccess: data => { const signedInUsername = data.username ?? username; localStorage.setItem(LOCAL_USERNAME_KEY, signedInUsername); setLocalUser(signedInUsername); setPassword(""); setAccountOpen(false); setAccountNotice(""); void sync(true); } });
  const changePassword = trpc.account.changePassword.useMutation({ onSuccess: () => { setAccountNotice("تم تغيير رمز الأدمن بنجاح"); setPassword(""); setNewPassword(""); setAccountMode("login"); } });
  const localLogout = trpc.account.logout.useMutation();
  const localAccess = Boolean(localUser);
  const offlineAccess = !isAuthenticated && !online && Boolean(localUser || cachedIdentity);
  const effectiveAccess = isAuthenticated || localAccess || offlineAccess;
  const snapshot = trpc.lab.snapshot.useQuery(undefined, { enabled: Boolean(isAuthenticated || localAccess) });
  const syncMutation = trpc.lab.sync.useMutation();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [status, setStatus] = useState<Status>("loading");
  const [frameReady, setFrameReady] = useState(false);
  const [lastHash, setLastHash] = useState("");

  const submitAccount = (event: React.FormEvent) => {
    event.preventDefault();
    setAccountNotice("");
    if (accountMode === "change") {
      changePassword.mutate({ currentPassword: password, newPassword });
    } else {
      localLogin.mutate({ username, password });
    }
  };

  useEffect(() => {
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => { window.removeEventListener("online", onOnline); window.removeEventListener("offline", onOffline); };
  }, []);

  const sync = useCallback(async (force = false) => {
    if (!effectiveAccess) return;
    const collected = collectLocalRecords();
    const serialized = JSON.stringify(collected.records.map(item => [item.id, item.updatedAt, item.payload]));
    if (!force && serialized === lastHash && navigator.onLine) return;
    writeMeta(collected.meta);
    if (!navigator.onLine) { setStatus("local"); setLastHash(serialized); return; }
    setStatus("syncing");
    try {
      const response = await syncMutation.mutateAsync({ records: collected.records.map(item => ({ ...item, deletedAt: item.deletedAt ?? null })) });
      applyServerRecords(response.records as LabRecord[]);
      setLastHash(JSON.stringify((response.records as LabRecord[]).map(item => [item.id, item.updatedAt, item.payload])));
      setStatus("synced");
    } catch {
      setStatus("local");
      setLastHash(serialized);
    }
  }, [effectiveAccess, isAuthenticated, lastHash, syncMutation]);

  useEffect(() => {
    if (!isAuthenticated || !snapshot.data) return;
    const serverRecords = snapshot.data.records as LabRecord[];
    if (!readArray(PATIENTS_KEY).length && !readArray(REPORTS_KEY).length && serverRecords.length) applyServerRecords(serverRecords);
    void sync(true).finally(() => setFrameReady(true));
  // The snapshot is stable after the first request; excluding the callback here
  // prevents its `lastHash` dependency from triggering a sync loop.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, snapshot.data]);

  useEffect(() => {
    if (!effectiveAccess) return;
    const interval = window.setInterval(() => void sync(), 1800);
    const handleOnline = () => void sync(true);
    window.addEventListener("online", handleOnline);
    return () => { window.clearInterval(interval); window.removeEventListener("online", handleOnline); };
  }, [effectiveAccess, sync]);

  useEffect(() => {
    if (!isAuthenticated || (effectiveAccess && !online)) { setStatus("local"); setFrameReady(true); }
  }, [effectiveAccess, isAuthenticated, online]);

  const statusLabel = status === "syncing" ? "جاري المزامنة" : status === "synced" ? "متزامن" : status === "local" ? "أوفلاين" : "تحميل";
  return <div className="original-shell"><iframe ref={iframeRef} title="نظام مختبر الجناح الخاص" src="/lab.html" /><div className={`sync-float ${status}`}><span>{status === "local" ? <CloudOff size={14} /> : <Cloud size={14} />}{isAuthenticated || localAccess ? (localUser || statusLabel) : "محلي"}</span>{!isAuthenticated && !localAccess && <button onClick={() => { setAccountMode("login"); setAccountOpen(true); }} title="دخول اسم المستخدم والرمز"><LogIn size={14} /></button>}{localAccess && <button onClick={() => { setAccountMode("change"); setAccountOpen(true); }} title="تغيير الرمز"><ShieldCheck size={14} /></button>}<button onClick={() => void sync(true)} disabled={!effectiveAccess || status === "syncing"} title={effectiveAccess ? "مزامنة الآن" : "دخول الحساب لتفعيل المزامنة"}><RefreshCw size={14} /></button>{(isAuthenticated || localAccess) && <button onClick={() => { localStorage.removeItem(IDENTITY_KEY); localStorage.removeItem(LOCAL_USERNAME_KEY); setLocalUser(""); localLogout.mutate(); if (isAuthenticated) void logout(); }} title="خروج"><LogOut size={14} /></button>}</div>{accountOpen && <div className="account-modal-backdrop"><form className="account-modal" dir="rtl" onSubmit={submitAccount}><button type="button" className="account-close" onClick={() => setAccountOpen(false)}>×</button><div className="auth-icon"><ShieldCheck size={28} /></div><h2>{accountMode === "change" ? "تغيير رمز الأدمن" : "دخول المزامنة"}</h2>{accountMode === "login" && <label>اسم المستخدم<input value={username} onChange={event => setUsername(event.target.value)} autoComplete="username" /></label>}<label>{accountMode === "change" ? "الرمز الحالي" : "الرمز"}<input type="password" value={password} onChange={event => setPassword(event.target.value)} autoComplete={accountMode === "change" ? "current-password" : "current-password"} /></label>{accountMode === "change" && <label>الرمز الجديد<input type="password" value={newPassword} onChange={event => setNewPassword(event.target.value)} autoComplete="new-password" /></label>}{accountNotice && <p className="account-notice">{accountNotice}</p>} {(localLogin.error || changePassword.error) && <p className="account-error">{localLogin.error?.message || changePassword.error?.message}</p>}<button className="account-submit" type="submit">{accountMode === "change" ? "حفظ الرمز الجديد" : "دخول"}</button>{accountMode === "change" && <button type="button" className="account-link" onClick={() => { setAccountMode("login"); setAccountNotice(""); }}>العودة لتسجيل الدخول</button>}<small>الحاسبة تفتح بدون حساب؛ الحساب فقط للمزامنة بين الأجهزة.</small></form></div>}</div>;
}
