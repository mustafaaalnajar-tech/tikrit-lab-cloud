export type LabRecordType = "patient" | "report";
export type LabRecord = { id: string; type: LabRecordType; payload: Record<string, unknown>; updatedAt: number; deletedAt?: number | null };

export function mergeRecords(local: LabRecord[], remote: LabRecord[]): LabRecord[] {
  const byId = new Map<string, LabRecord>();
  for (const record of [...local, ...remote]) {
    const current = byId.get(record.id);
    if (!current || record.updatedAt >= current.updatedAt) byId.set(record.id, record);
  }
  return Array.from(byId.values()).sort((a, b) => b.updatedAt - a.updatedAt);
}

export function storageKey(identity: string) { return `tikrit-lab-sync:${identity}`; }
export function readLocal(identity: string): LabRecord[] {
  if (!identity || typeof window === "undefined") return [];
  try { const parsed = JSON.parse(window.localStorage.getItem(storageKey(identity)) || "[]"); return Array.isArray(parsed) ? parsed : []; } catch { return []; }
}
export function writeLocal(identity: string, records: LabRecord[]) { if (identity && typeof window !== "undefined") window.localStorage.setItem(storageKey(identity), JSON.stringify(records)); }
export function newRecord(type: LabRecordType, payload: Record<string, unknown>): LabRecord { return { id: `${type}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`, type, payload, updatedAt: Date.now(), deletedAt: null }; }
export function pendingRecords(records: LabRecord[]) { return records; }
