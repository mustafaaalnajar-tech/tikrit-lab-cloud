import { describe, expect, it } from "vitest";
import { mergeRecords, type LabRecord } from "./offlineSync";

const item = (id: string, updatedAt: number, result: string, deletedAt: number | null = null): LabRecord => ({
  id, type: "report", payload: { result }, updatedAt, deletedAt,
});

describe("offline sync merge", () => {
  it("keeps a newer local edit over a stale server record", () => {
    expect(mergeRecords([item("report:1", 20, "local")], [item("report:1", 10, "server")])[0]?.payload.result).toBe("local");
  });

  it("accepts a newer server record on a second laptop", () => {
    expect(mergeRecords([item("report:1", 10, "old")], [item("report:1", 20, "new")])[0]?.payload.result).toBe("new");
  });

  it("preserves tombstones so deleted records do not return", () => {
    const merged = mergeRecords([item("report:1", 30, "", 30)], [item("report:1", 20, "present")]);
    expect(merged[0]?.deletedAt).toBe(30);
  });

  it("converges after repeating the same merge", () => {
    const local = [item("report:1", 10, "local")];
    const server = [item("report:1", 20, "server")];
    expect(mergeRecords(mergeRecords(local, server), server)).toEqual(mergeRecords(local, server));
  });
});
